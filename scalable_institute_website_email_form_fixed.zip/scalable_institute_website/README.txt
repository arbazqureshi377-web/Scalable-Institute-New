SCALABLE INSTITUTE OF CS & IT - WEBSITE

Open index.html in a browser.

CONTACT FORM EMAIL SETUP
The enrollment form is configured to submit enquiries through FormSubmit to:
scalable.institute.tech@gmail.com

IMPORTANT FIRST-TIME STEP:
On the first form submission, FormSubmit may send an activation/confirmation email to the destination Gmail address. Open that email and confirm/activate the form. After activation, future enquiries can be delivered automatically.

The website does not contain or expose a Gmail password.
